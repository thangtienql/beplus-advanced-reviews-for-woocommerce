<?php
/**
 * StylingModule — injects admin-controlled color overrides as inline CSS.
 *
 * @package BeplusAdvancedReviewsForWoocommerce
 * @subpackage Styling
 */

namespace BeplusAdvancedReviewsForWoocommerce\Styling;

use BeplusAdvancedReviewsForWoocommerce\Core\AbstractModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class StylingModule extends AbstractModule {

	/**
	 * Map of settings keys to CSS custom property names.
	 *
	 * @var array<string, string>
	 */
	private const COLOR_MAP = array(
		'primary'        => '--bpar-primary',
		'text'           => '--bpar-text',
		'bg'             => '--bpar-bg',
		'button_text'    => '--bpar-button-text',
		'star_empty'     => '--bpar-star-empty',
		'error_bg'       => '--bpar-error-bg',
		'error_text'     => '--bpar-error-text',
		'error_border'   => '--bpar-error-border',
		'success_bg'     => '--bpar-success-bg',
		'success_text'   => '--bpar-success-text',
		'success_border' => '--bpar-success-border',
	);

	/**
	 * Default color values — must match SettingsRegistry::get_defaults()['colors'].
	 *
	 * @var array<string, string>
	 */
	private const DEFAULTS = array(
		'primary'        => '#000000',
		'text'           => '#000000',
		'bg'             => '#FFFFFF',
		'button_text'    => '#ffffff',
		'star_empty'     => '#CFCFCF',
		'error_bg'       => '#f8d7da',
		'error_text'     => '#721c24',
		'error_border'   => '#f5c6cb',
		'success_bg'     => '#d4edda',
		'success_text'   => '#155724',
		'success_border' => '#c3e6cb',
	);

	public function register(): void {
		add_action( 'wp_head', array( $this, 'output_inline_css' ), 9999 );
	}

	/**
	 * Output inline <style> block overriding --bpar-* custom properties.
	 *
	 * Only outputs when admin has changed at least one color from its default.
	 *
	 * @return void
	 */
	public function output_inline_css(): void {
		if ( ! function_exists( 'beplus_advanced_reviews_for_woocommerce_get_settings' ) ) {
			return;
		}

		$settings = beplus_advanced_reviews_for_woocommerce_get_settings();
		$colors   = $settings['colors'] ?? array();

		if ( ! is_array( $colors ) ) {
			return;
		}

		// Only output tokens that differ from defaults — the rest stay in style.css.
		// Compare case-insensitively: native <input type="color"> always returns lowercase hex.
		$css_rules = array();
		foreach ( self::COLOR_MAP as $key => $var ) {
			$sanitized = sanitize_hex_color( (string) ( $colors[ $key ] ?? '' ) );
			$current   = $sanitized ? strtoupper( $sanitized ) : '';
			$default   = strtoupper( self::DEFAULTS[ $key ] );
			if ( '' !== $current && $current !== $default ) {
				$css_rules[ $var ] = $current;
			}
		}

		if ( empty( $css_rules ) ) {
			return;
		}

		echo '<style id="bparfw-custom-colors">' . "\n:root {\n";
		foreach ( $css_rules as $var => $value ) {
			echo '  ' . esc_html( $var ) . ': ' . esc_html( $value ) . ";\n";
		}
		echo "}\n</style>\n";
	}
}
